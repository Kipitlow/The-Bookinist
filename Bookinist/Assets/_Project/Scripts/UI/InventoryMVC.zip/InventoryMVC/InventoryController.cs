using UnityEditor;
using UnityEngine;

public class InventoryController : MonoBehaviour
{
    #region Variables
    [SerializeField] private InventoryModel _inventoryModel;
    [SerializeField] private InventoryView _inventoryView;
    [SerializeField] private Item _emptySlot;
    public Item activeItem;

    #endregion

    #region Unity Methods
    private void OnEnable()
    {
        ItemController.onItemClicked += HandleItemClicked;
    }

    private void OnDisable()
    {
        ItemController.onItemClicked -= HandleItemClicked;
    }

    #endregion

    #region Methods

    public void AddInventoryItem(Item ItemToAdd)
    {
        _inventoryModel.AddItem(ItemToAdd);
        UpdateInventory();
    }
    public void RemoveInventoryItem(Item ItemToAdd)
    {
        _inventoryModel.RemoveItem(ItemToAdd);
        UpdateInventory();
        activeItem = _emptySlot;
    }

    public void UpdateInventory()
    {
        _inventoryView.UpdateInventory(_inventoryModel.GetInventoryContent());
    }

    private void HandleItemClicked(Item item)
    {
        Debug.Log($"Clicked: {item.name}");
        activeItem = item;
    }

    #endregion
}
